<form action="<?= site_url('admin/jadwal_edit_go')?>" method="post">
		<table style="margin:20px auto;">
		<tr>
				<td>id</td>
				<td><input type="text" readonly name="id" value="<?=$id?>"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" readonly name="nama_penyewa" value="<?=$nama_penyewa?>"></td>
			</tr>
			<tr>
				<td>Waktu</td>
				<td><input type="text" name="waktu_sewa" value="<?=$waktu_sewa?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Edit"></td>
			</tr>
		</table>
	</form>	