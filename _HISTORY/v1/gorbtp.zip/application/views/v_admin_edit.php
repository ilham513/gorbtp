<form action="<?= site_url('admin/edit_go')?>" method="post">
		<table style="margin:20px auto;">
		<tr>
				<td>id</td>
				<td><input type="text" readonly name="id" value="<?=$id?>"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama" value="<?=$nama?>"></td>
			</tr>
			<tr>
				<td>No Telp</td>
				<td><input type="text" name="no_telp" value="<?=$no_telp?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Edit"></td>
			</tr>
		</table>
	</form>	