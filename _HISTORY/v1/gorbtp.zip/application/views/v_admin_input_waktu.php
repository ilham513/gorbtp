<form action="<?= site_url('admin/input_waktu_go')?>" method="post">
		<table style="margin:20px auto;">
			<tr>
				<td>Hari</td>
				<td><input type="text" name="hari"></td>
			</tr>
			<tr>
				<td>Jam</td>
				<td><input type="text" name="jam"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Tambah"></td>
			</tr>
		</table>
	</form>	